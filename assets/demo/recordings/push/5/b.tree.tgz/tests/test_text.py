from app.text import slugify


def test_slugify_simple():
    assert slugify("hello") == "hello"


def test_slugify_with_punctuation():
    assert slugify("Hello, World!") == "hello-world"


def test_slugify_consecutive_special_chars():
    assert slugify("test---case") == "test-case"


def test_slugify_leading_trailing_special():
    assert slugify("!hello!") == "hello"
