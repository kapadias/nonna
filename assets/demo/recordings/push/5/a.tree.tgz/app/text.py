"""Text helpers."""

import re


def slugify(title: str) -> str:
    """Turn a title into a URL slug: 'Hello, World!' -> 'hello-world'."""
    slug = re.sub(r"[^a-z0-9]", "-", title.lower())
    slug = re.sub(r"-+", "-", slug).strip("-")
    return slug
