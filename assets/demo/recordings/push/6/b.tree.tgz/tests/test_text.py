from app.text import slugify


def test_slugify_simple():
    assert slugify("hello") == "hello"


def test_slugify_with_punctuation():
    assert slugify("Hello, World!") == "hello-world"


def test_slugify_multiple_spaces():
    assert slugify("hello  world") == "hello-world"


def test_slugify_leading_trailing_special_chars():
    assert slugify("!hello-world!") == "hello-world"


def test_slugify_mixed_punctuation():
    assert slugify("Hello, World! How are you?") == "hello-world-how-are-you"
