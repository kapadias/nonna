from app.text import slugify


def test_slugify_simple():
    assert slugify("hello") == "hello"


def test_slugify_removes_punctuation():
    assert slugify("Hello, World!") == "hello-world"


def test_slugify_handles_multiple_spaces():
    assert slugify("hello   world") == "hello-world"


def test_slugify_strips_trailing_dashes():
    assert slugify("hello-world!") == "hello-world"


def test_slugify_strips_leading_dashes():
    assert slugify("!hello-world") == "hello-world"
