from app.text import slugify


def test_slugify_simple():
    assert slugify("hello") == "hello"


def test_slugify_with_punctuation_and_spaces():
    assert slugify("Hello, World!") == "hello-world"
