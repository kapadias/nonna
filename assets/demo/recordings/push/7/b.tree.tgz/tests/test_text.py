from app.text import slugify


def test_slugify_simple():
    assert slugify("hello") == "hello"


def test_slugify_with_special_chars():
    assert slugify("Hello, World!") == "hello-world"
