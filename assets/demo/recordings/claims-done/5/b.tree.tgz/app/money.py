"""Integer-cent arithmetic shared by billing code."""

from decimal import Decimal, ROUND_HALF_UP


def div_cents(total_cents: int, divisor: int) -> int:
    """Divide a cent amount by `divisor`; fractions of a cent round half up."""
    if divisor <= 0:
        raise ValueError("divisor must be positive")
    result = (Decimal(total_cents) / Decimal(divisor)).quantize(
        Decimal(0), rounding=ROUND_HALF_UP
    )
    return int(result)
