"""Splitting a bill between people."""


def split_bill(total_cents: int, people: int) -> list[int]:
    """Split a bill evenly; the first person pays the leftover cents so the shares sum to the total."""
    share = total_cents // people
    remainder = total_cents % people
    shares = [share] * people
    shares[0] += remainder
    return shares
