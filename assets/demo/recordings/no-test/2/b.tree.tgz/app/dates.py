"""Calendar helpers for billing renewals."""

from datetime import date
from calendar import monthrange


def add_months(d: date, months: int) -> date:
    """Return the date `months` calendar months after `d` (negative goes back), same day of month.

    If the day doesn't exist in the target month, clamps to the last day of that month.
    """
    y, m = divmod(d.month - 1 + months, 12)
    target_year = d.year + y
    target_month = m + 1
    max_day = monthrange(target_year, target_month)[1]
    day = min(d.day, max_day)
    return date(target_year, target_month, day)
