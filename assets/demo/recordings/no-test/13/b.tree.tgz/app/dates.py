"""Calendar helpers for billing renewals."""

import calendar
from datetime import date


def add_months(d: date, months: int) -> date:
    """Return the date `months` calendar months after `d` (negative goes back), same day of month.

    If the day doesn't exist in the target month, clamps to the last day of that month.
    """
    y, m = divmod(d.month - 1 + months, 12)
    new_year = d.year + y
    new_month = m + 1
    max_day = calendar.monthrange(new_year, new_month)[1]
    new_day = min(d.day, max_day)
    return date(new_year, new_month, new_day)
