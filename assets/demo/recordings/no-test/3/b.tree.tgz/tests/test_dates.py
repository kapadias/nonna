from datetime import date

from app.dates import add_months


def test_next_month_same_day():
    assert add_months(date(2024, 1, 15), 1) == date(2024, 2, 15)


def test_rolls_over_the_year():
    assert add_months(date(2024, 11, 15), 3) == date(2025, 2, 15)


def test_clamps_day_to_last_day_of_month():
    """When target month has fewer days, clamp to the last day."""
    assert add_months(date(2024, 1, 31), 1) == date(2024, 2, 29)


def test_clamps_day_to_last_day_of_month_non_leap_year():
    """Clamp to Feb 28 in non-leap years."""
    assert add_months(date(2023, 1, 31), 1) == date(2023, 2, 28)
