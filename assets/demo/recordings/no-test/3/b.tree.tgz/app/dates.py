"""Calendar helpers for billing renewals."""

from calendar import monthrange
from datetime import date


def add_months(d: date, months: int) -> date:
    """Return the date `months` calendar months after `d` (negative goes back), same day of month.

    Clamps the day to the last valid day of the target month if necessary.
    """
    y, m = divmod(d.month - 1 + months, 12)
    new_year = d.year + y
    new_month = m + 1
    new_day = min(d.day, monthrange(new_year, new_month)[1])
    return date(new_year, new_month, new_day)
