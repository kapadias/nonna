"""Calendar helpers for billing renewals."""

import calendar
from datetime import date


def add_months(d: date, months: int) -> date:
    """Return the date `months` calendar months after `d` (negative goes back), same day of month.

    If the target month has fewer days, clamps to the last day of that month.
    """
    y, m = divmod(d.month - 1 + months, 12)
    last_day = calendar.monthrange(d.year + y, m + 1)[1]
    day = min(d.day, last_day)
    return d.replace(year=d.year + y, month=m + 1, day=day)
