"""Calendar helpers for billing renewals."""

from datetime import date
from calendar import monthrange


def add_months(d: date, months: int) -> date:
    """Return the date `months` calendar months after `d` (negative goes back), same day of month.

    Clamps to the last day of the target month if the original day doesn't exist (e.g. Jan 31 + 1 month = Feb 29).
    """
    y, m = divmod(d.month - 1 + months, 12)
    target_year = d.year + y
    target_month = m + 1
    last_day = monthrange(target_year, target_month)[1]
    target_day = min(d.day, last_day)
    return date(target_year, target_month, target_day)
