"""Calendar helpers for billing renewals."""

import calendar
from datetime import date


def add_months(d: date, months: int) -> date:
    """Return the date `months` calendar months after `d` (negative goes back), same day of month or last day if out of range."""
    y, m = divmod(d.month - 1 + months, 12)
    target_year = d.year + y
    target_month = m + 1

    last_day_of_month = calendar.monthrange(target_year, target_month)[1]
    target_day = min(d.day, last_day_of_month)

    return date(target_year, target_month, target_day)
