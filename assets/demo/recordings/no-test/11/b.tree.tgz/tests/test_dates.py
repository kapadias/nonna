from datetime import date

from app.dates import add_months


def test_next_month_same_day():
    assert add_months(date(2024, 1, 15), 1) == date(2024, 2, 15)


def test_rolls_over_the_year():
    assert add_months(date(2024, 11, 15), 3) == date(2025, 2, 15)


def test_clamps_day_to_last_day_of_month():
    # Jan 31 + 1 month = Feb 29 (leap year)
    assert add_months(date(2024, 1, 31), 1) == date(2024, 2, 29)
    # Jan 31 + 2 months = Mar 31 (has 31 days, no clamping needed)
    assert add_months(date(2024, 1, 31), 2) == date(2024, 3, 31)
    # Jan 31 + 3 months = Apr 30 (clamped from 31)
    assert add_months(date(2024, 1, 31), 3) == date(2024, 4, 30)
