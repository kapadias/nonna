"""Calendar helpers for billing renewals."""

import calendar
from datetime import date


def add_months(d: date, months: int) -> date:
    """Return the date `months` calendar months after `d` (negative goes back), clamped to the last day if needed."""
    y, m = divmod(d.month - 1 + months, 12)
    new_year = d.year + y
    new_month = m + 1
    days_in_new_month = calendar.monthrange(new_year, new_month)[1]
    new_day = min(d.day, days_in_new_month)
    return d.replace(year=new_year, month=new_month, day=new_day)
