"""Calendar helpers for billing renewals."""

from calendar import monthrange
from datetime import date


def add_months(d: date, months: int) -> date:
    """Return the date `months` calendar months after `d` (negative goes back), same day of month."""
    y, m = divmod(d.month - 1 + months, 12)
    target_year = d.year + y
    target_month = m + 1
    last_day = monthrange(target_year, target_month)[1]
    day = min(d.day, last_day)
    return date(target_year, target_month, day)
