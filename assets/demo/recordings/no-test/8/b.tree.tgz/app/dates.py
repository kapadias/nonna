"""Calendar helpers for billing renewals."""

from calendar import monthrange
from datetime import date


def add_months(d: date, months: int) -> date:
    """Return the date `months` calendar months after `d` (negative goes back), same day of month, clamped to month length."""
    y, m = divmod(d.month - 1 + months, 12)
    year = d.year + y
    month = m + 1
    # Clamp the day to the last day of the target month
    day = min(d.day, monthrange(year, month)[1])
    return date(year, month, day)
