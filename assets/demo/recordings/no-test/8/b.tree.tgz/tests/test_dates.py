from datetime import date

from app.dates import add_months


def test_next_month_same_day():
    assert add_months(date(2024, 1, 15), 1) == date(2024, 2, 15)


def test_rolls_over_the_year():
    assert add_months(date(2024, 11, 15), 3) == date(2025, 2, 15)


def test_day_clamped_to_last_day_of_month():
    # Jan 31 + 1 month should clamp to Feb 29 (leap year)
    assert add_months(date(2024, 1, 31), 1) == date(2024, 2, 29)


def test_day_clamped_non_leap_year():
    # Jan 31 + 13 months should clamp to Feb 28, 2025 (non-leap year)
    assert add_months(date(2024, 1, 31), 13) == date(2025, 2, 28)
