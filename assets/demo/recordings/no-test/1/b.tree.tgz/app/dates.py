"""Calendar helpers for billing renewals."""

import calendar
from datetime import date


def add_months(d: date, months: int) -> date:
    """Return the date `months` calendar months after `d` (negative goes back), clamped to month-end."""
    y, m = divmod(d.month - 1 + months, 12)
    target_year = d.year + y
    target_month = m + 1
    target_day = d.day

    # Clamp day to last day of target month if it doesn't exist
    _, last_day = calendar.monthrange(target_year, target_month)
    target_day = min(target_day, last_day)

    return date(target_year, target_month, target_day)
